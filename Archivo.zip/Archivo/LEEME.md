# Programas importantes en la [Informática](https://youtu.be/wVeLg2PsVPg?si=pA4LlVqIRJUocmus)

En informática es muy común buscar programas con los que puedas optimizar el tiempo para realizar tareas que normalmente a mano tardarías mucho. Algunos ejemplos son:

- Excel
- Word
- Powerpoint
- Microsoft Access

Todos estos forman parte del paquete de Microsoft Office 365.
[Como Activar el Office](https://youtu.be/F_U7ZqC7xwI?si=S9Xx58vbRegG_bWq).

> El enlace es para obtener el office gratuito, dependiendo de tu ordenador puede que te funcione.

# Importante

Es muy usual ver a mucha gente escribir solamente con los dedos índices el teclado, pero algo que reduce el tiempo notoriamente al usar un ordenador es aprender mecanografía. Se basa en aprender a escribir con todos los dedos de tus manos.

Enlaces que te pueden servir:
[Typing](https://www.bing.com/ck/a?!&&p=7e463202c3cb1c03b6c96d724fe77ef7ce1e15c5e0add8aed2b426c9c260cc9fJmltdHM9MTc2MDQwMDAwMA&ptn=3&ver=2&hsh=4&fclid=072eb878-8950-6eb9-347b-ae1888216f6f&psq=mecanografia+online&u=a1aHR0cHM6Ly93d3cudHlwaW5nLmNvbS9lcy9zdHVkZW50L2xlc3NvbnM) -
[Eddub](https://www.edclub.com/es/library/el-mundo-de-la-mecanograf%C3%ADa) -
[Keybr](https://www.keybr.com/) -
[Video de Rutina](https://youtu.be/gCtBGEh_WkE?si=P8aUOqQct9EyI6Oh)

# Aprende conceptos básicos de programación, te puede servir.

Incluye:

- Introducción a Dibujo por código.
- Introducción a HTML/CSS.
- Introducción a Consulta y Gestión de Base de Datos.
- Creación de paginas web simples e interactivas.

---

**¡¡¡INGRESA AL ENLACE AQUÍ ABAJO!!!**

[Khan Academy](https://es.khanacademy.org/computing/computer-programming)

> Totalmente gratuito, se sugiere crear una cuenta para guardar el progreso.

---

Si no logras comprender muy bien el tema, basta con buscar en YouTube conceptos fundamentales.
He aquí algunos enlaces que te pueden servir.

[Video 1](https://youtu.be/VxrIZGQfxmE?si=gnWwQP8Pq_sWPofA) -
[Video 2](https://youtu.be/dQtj19lGrHY?si=xAkCH56RvOCf5ASI)

> Toma en cuenta que la programación se basa en constante práctica y error. Desafíate a ti mismo averíguando como resolver un problema.
